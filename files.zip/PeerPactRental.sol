// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ============================================================
//  PeerPact Rental — Stablecoin Escrow Smart Contract
//  Built for Polkadot Hub EVM (EVM-compatible, any ERC-20)
//  Hackathon Demo — UTM 2025
// ============================================================

/**
 * @dev Minimal ERC-20 interface — only the functions we need
 * Works with any stablecoin: USDC, USDT, or your own mock ERC-20
 */
interface IERC20 {
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function allowance(address owner, address spender) external view returns (uint256);
}

/**
 * @title PeerPactRental
 * @notice Trustless rental agreement with stablecoin escrow for Malaysian students
 *
 * FLOW:
 *   1. Landlord creates a listing (room details, monthly rent, deposit amount)
 *   2. Tenant accepts listing → locks deposit in stablecoin into this contract
 *   3. Tenant pays rent monthly → stablecoin transfers to landlord
 *   4. At end of tenancy → deposit auto-returns to tenant
 *   5. Either party can raise a dispute → contract freezes → arbitrator resolves
 *
 * WHY STABLECOIN:
 *   Native token price fluctuates. A 12-month RM500/month rental agreement
 *   must guarantee RM500 every month — only possible with stablecoin.
 */
contract PeerPactRental {

    // ─────────────────────────────────────────────
    //  ENUMS & STRUCTS
    // ─────────────────────────────────────────────

    enum AgreementStatus {
        PENDING,    // Listing created by landlord, no tenant yet
        ACTIVE,     // Tenant accepted, deposit locked
        DISPUTED,   // One party raised a dispute — contract frozen
        ENDED,      // Tenancy ended normally — deposit returned
        RESOLVED    // Dispute resolved by arbitrator
    }

    struct Agreement {
        // Parties
        address payable landlord;
        address payable tenant;

        // Financial terms (in stablecoin units, e.g. 6 decimals for USDC)
        uint256 monthlyRent;        // e.g. 500_000000 = 500 USDC
        uint256 depositAmount;      // e.g. 1000_000000 = 1000 USDC (2 months typical)

        // Timing
        uint256 startTimestamp;     // When tenancy started
        uint256 durationMonths;     // Total tenancy length in months
        uint256 lastRentPaidAt;     // Timestamp of last rent payment
        uint256 rentPaidCount;      // How many months rent has been paid

        // State
        AgreementStatus status;
        bool depositLocked;         // True once tenant locks deposit

        // Dispute
        address disputeRaisedBy;    // Who raised the dispute
        string  disputeReason;      // Reason for dispute

        // Metadata (stored as strings for demo simplicity)
        string  roomTitle;          // e.g. "Master Room @ Taman Universiti"
        string  roomLocation;       // e.g. "Skudai, Johor"
    }

    // ─────────────────────────────────────────────
    //  STATE VARIABLES
    // ─────────────────────────────────────────────

    IERC20  public immutable stablecoin;   // Stablecoin contract (USDC/USDT/mock)
    address public arbitrator;             // Trusted 3rd party (e.g. UTM admin wallet)

    uint256 public agreementCount;
    mapping(uint256 => Agreement) public agreements;

    // Track all agreements per address for easy frontend querying
    mapping(address => uint256[]) public landlordAgreements;
    mapping(address => uint256[]) public tenantAgreements;

    // Platform fee: 1% of each rent payment (hackathon demo revenue model)
    uint256 public constant PLATFORM_FEE_BPS = 100; // 100 basis points = 1%
    address public platformWallet;
    uint256 public platformFeesCollected;

    // Rent grace period: tenant has 3 days after due date before considered late
    uint256 public constant GRACE_PERIOD = 3 days;
    // Minimum tenancy: 1 month
    uint256 public constant MIN_DURATION_MONTHS = 1;
    // Maximum tenancy: 24 months
    uint256 public constant MAX_DURATION_MONTHS = 24;

    // ─────────────────────────────────────────────
    //  EVENTS — frontend listens to these
    // ─────────────────────────────────────────────

    event ListingCreated(
        uint256 indexed agreementId,
        address indexed landlord,
        string roomTitle,
        uint256 monthlyRent,
        uint256 depositAmount,
        uint256 durationMonths
    );

    event TenantAccepted(
        uint256 indexed agreementId,
        address indexed tenant,
        uint256 depositAmount,
        uint256 startTimestamp
    );

    event RentPaid(
        uint256 indexed agreementId,
        address indexed tenant,
        uint256 amount,
        uint256 month,
        uint256 timestamp
    );

    event DepositReturned(
        uint256 indexed agreementId,
        address indexed tenant,
        uint256 amount
    );

    event DisputeRaised(
        uint256 indexed agreementId,
        address indexed raisedBy,
        string reason
    );

    event DisputeResolved(
        uint256 indexed agreementId,
        address indexed winner,
        uint256 amountToLandlord,
        uint256 amountToTenant
    );

    event TenancyEnded(
        uint256 indexed agreementId,
        uint256 timestamp
    );

    // ─────────────────────────────────────────────
    //  MODIFIERS
    // ─────────────────────────────────────────────

    modifier onlyArbitrator() {
        require(msg.sender == arbitrator, "PeerPact: Not arbitrator");
        _;
    }

    modifier agreementExists(uint256 _id) {
        require(_id > 0 && _id <= agreementCount, "PeerPact: Agreement not found");
        _;
    }

    modifier onlyParties(uint256 _id) {
        Agreement storage a = agreements[_id];
        require(
            msg.sender == a.landlord || msg.sender == a.tenant,
            "PeerPact: Not a party to this agreement"
        );
        _;
    }

    modifier onlyActive(uint256 _id) {
        require(
            agreements[_id].status == AgreementStatus.ACTIVE,
            "PeerPact: Agreement not active"
        );
        _;
    }

    // ─────────────────────────────────────────────
    //  CONSTRUCTOR
    // ─────────────────────────────────────────────

    /**
     * @param _stablecoin  Address of ERC-20 stablecoin (USDC, USDT, or mock)
     * @param _arbitrator  Trusted address to resolve disputes (UTM admin / multisig)
     * @param _platform    Wallet to receive 1% platform fees
     *
     * DEPLOY EXAMPLE (Remix / Hardhat):
     *   _stablecoin = "0xYourMockUSDCAddress"
     *   _arbitrator = "0xYourAdminWallet"
     *   _platform   = "0xYourPlatformWallet"
     */
    constructor(
        address _stablecoin,
        address _arbitrator,
        address _platform
    ) {
        require(_stablecoin  != address(0), "PeerPact: Invalid stablecoin");
        require(_arbitrator  != address(0), "PeerPact: Invalid arbitrator");
        require(_platform    != address(0), "PeerPact: Invalid platform wallet");

        stablecoin     = IERC20(_stablecoin);
        arbitrator     = _arbitrator;
        platformWallet = _platform;
    }

    // ─────────────────────────────────────────────
    //  CORE FUNCTIONS
    // ─────────────────────────────────────────────

    /**
     * @notice STEP 1 — Landlord creates a room listing
     * @param _roomTitle      Human-readable room title
     * @param _roomLocation   Location string
     * @param _monthlyRent    Rent per month in stablecoin units
     * @param _depositAmount  Deposit amount in stablecoin units (usually 2x rent)
     * @param _durationMonths Length of tenancy in months
     *
     * FRONTEND: Call this when landlord submits "List Room" form
     * NOTE: Landlord does NOT transfer anything here — only tenant transfers
     */
    function createListing(
        string calldata _roomTitle,
        string calldata _roomLocation,
        uint256 _monthlyRent,
        uint256 _depositAmount,
        uint256 _durationMonths
    ) external returns (uint256 agreementId) {
        require(bytes(_roomTitle).length    > 0, "PeerPact: Empty title");
        require(bytes(_roomLocation).length > 0, "PeerPact: Empty location");
        require(_monthlyRent               > 0, "PeerPact: Rent must be > 0");
        require(_depositAmount             > 0, "PeerPact: Deposit must be > 0");
        require(
            _durationMonths >= MIN_DURATION_MONTHS &&
            _durationMonths <= MAX_DURATION_MONTHS,
            "PeerPact: Duration out of range (1–24 months)"
        );

        agreementCount++;
        agreementId = agreementCount;

        Agreement storage a    = agreements[agreementId];
        a.landlord             = payable(msg.sender);
        a.monthlyRent          = _monthlyRent;
        a.depositAmount        = _depositAmount;
        a.durationMonths       = _durationMonths;
        a.status               = AgreementStatus.PENDING;
        a.roomTitle            = _roomTitle;
        a.roomLocation         = _roomLocation;

        landlordAgreements[msg.sender].push(agreementId);

        emit ListingCreated(
            agreementId,
            msg.sender,
            _roomTitle,
            _monthlyRent,
            _depositAmount,
            _durationMonths
        );
    }

    /**
     * @notice STEP 2 — Tenant accepts listing and locks deposit
     * @param _agreementId  The listing ID to accept
     *
     * FRONTEND: Tenant clicks "Rent This Room" → wallet asks approval → this runs
     *
     * BEFORE CALLING: Tenant must approve this contract to spend stablecoin:
     *   stablecoin.approve(contractAddress, depositAmount)
     *
     * WHY STABLECOIN IS A MUST HERE:
     *   Deposit is locked for months. If native token is used, value fluctuates.
     *   Stablecoin guarantees tenant gets back exactly what they put in.
     */
    function acceptListing(uint256 _agreementId)
        external
        agreementExists(_agreementId)
    {
        Agreement storage a = agreements[_agreementId];

        require(a.status  == AgreementStatus.PENDING, "PeerPact: Not available");
        require(msg.sender != a.landlord,              "PeerPact: Landlord cannot be tenant");

        // Check tenant has approved enough stablecoin
        uint256 allowed = stablecoin.allowance(msg.sender, address(this));
        require(allowed >= a.depositAmount, "PeerPact: Insufficient stablecoin allowance");

        // Lock deposit into this contract
        bool success = stablecoin.transferFrom(msg.sender, address(this), a.depositAmount);
        require(success, "PeerPact: Deposit transfer failed");

        // Update agreement
        a.tenant           = payable(msg.sender);
        a.startTimestamp   = block.timestamp;
        a.lastRentPaidAt   = block.timestamp;
        a.depositLocked    = true;
        a.status           = AgreementStatus.ACTIVE;

        tenantAgreements[msg.sender].push(_agreementId);

        emit TenantAccepted(
            _agreementId,
            msg.sender,
            a.depositAmount,
            block.timestamp
        );
    }

    /**
     * @notice STEP 3 — Tenant pays monthly rent
     * @param _agreementId  The active agreement ID
     *
     * FRONTEND: "Pay Rent" button visible on tenant dashboard every month
     *
     * BEFORE CALLING: Tenant must approve monthly rent amount:
     *   stablecoin.approve(contractAddress, monthlyRent)
     *
     * WHY STABLECOIN IS A MUST HERE:
     *   Contract must send exactly RM500 worth every month.
     *   Native token cannot guarantee fixed fiat value — stablecoin can.
     */
    function payRent(uint256 _agreementId)
        external
        agreementExists(_agreementId)
        onlyActive(_agreementId)
    {
        Agreement storage a = agreements[_agreementId];

        require(msg.sender == a.tenant, "PeerPact: Only tenant can pay rent");
        require(
            a.rentPaidCount < a.durationMonths,
            "PeerPact: All rent months already paid"
        );

        // Check rent is due (at least 25 days since last payment — allows flexibility)
        require(
            block.timestamp >= a.lastRentPaidAt + 25 days,
            "PeerPact: Rent not due yet"
        );

        // Calculate platform fee (1%)
        uint256 fee           = (a.monthlyRent * PLATFORM_FEE_BPS) / 10000;
        uint256 landlordShare = a.monthlyRent - fee;

        // Transfer rent from tenant
        bool success = stablecoin.transferFrom(msg.sender, address(this), a.monthlyRent);
        require(success, "PeerPact: Rent transfer failed");

        // Send landlord share immediately
        stablecoin.transfer(a.landlord, landlordShare);

        // Accumulate platform fee
        stablecoin.transfer(platformWallet, fee);
        platformFeesCollected += fee;

        // Update state
        a.lastRentPaidAt = block.timestamp;
        a.rentPaidCount++;

        emit RentPaid(
            _agreementId,
            msg.sender,
            a.monthlyRent,
            a.rentPaidCount,
            block.timestamp
        );

        // Auto-end tenancy if all months paid
        if (a.rentPaidCount == a.durationMonths) {
            _endTenancy(_agreementId);
        }
    }

    /**
     * @notice STEP 4 — End tenancy early (mutual agreement)
     * @param _agreementId  The active agreement ID
     *
     * FRONTEND: "End Tenancy" button — only visible to both parties
     * Both landlord AND tenant must call this to confirm early termination
     */
    mapping(uint256 => mapping(address => bool)) public endTenancyConsent;

    function requestEndTenancy(uint256 _agreementId)
        external
        agreementExists(_agreementId)
        onlyActive(_agreementId)
        onlyParties(_agreementId)
    {
        endTenancyConsent[_agreementId][msg.sender] = true;

        Agreement storage a = agreements[_agreementId];

        // Only end if BOTH parties agreed
        if (
            endTenancyConsent[_agreementId][a.landlord] &&
            endTenancyConsent[_agreementId][a.tenant]
        ) {
            _endTenancy(_agreementId);
        }
    }

    /**
     * @notice STEP 5 — Raise a dispute
     * @param _agreementId  The active agreement ID
     * @param _reason       Plain text reason for dispute
     *
     * FRONTEND: "Raise Dispute" button — visible to both parties on agreement page
     * Freezes the contract — no rent payments or deposit returns until resolved
     *
     * WHY THIS MATTERS FOR MALAYSIA:
     *   Replaces the "syarahan baik punya" WhatsApp argument with a formal
     *   on-chain record that an arbitrator can review transparently
     */
    function raiseDispute(uint256 _agreementId, string calldata _reason)
        external
        agreementExists(_agreementId)
        onlyActive(_agreementId)
        onlyParties(_agreementId)
    {
        require(bytes(_reason).length > 0, "PeerPact: Reason required");

        Agreement storage a  = agreements[_agreementId];
        a.status             = AgreementStatus.DISPUTED;
        a.disputeRaisedBy    = msg.sender;
        a.disputeReason      = _reason;

        emit DisputeRaised(_agreementId, msg.sender, _reason);
    }

    /**
     * @notice STEP 6 — Arbitrator resolves a dispute
     * @param _agreementId      Disputed agreement ID
     * @param _landlordShare    How much of deposit goes to landlord (for damages)
     * @param _tenantShare      How much of deposit returns to tenant
     *
     * FRONTEND: Admin dashboard — only visible to arbitrator wallet
     *
     * NOTE: _landlordShare + _tenantShare must equal depositAmount
     *
     * WHY ARBITRATOR NOT AUTOMATIC:
     *   "Did the tenant damage the walls?" cannot be verified on-chain.
     *   This is the Oracle Problem. Arbitrator is the trusted human bridge.
     *   (Could be upgraded to Kleros decentralized arbitration later)
     */
    function resolveDispute(
        uint256 _agreementId,
        uint256 _landlordShare,
        uint256 _tenantShare
    )
        external
        onlyArbitrator
        agreementExists(_agreementId)
    {
        Agreement storage a = agreements[_agreementId];
        require(a.status == AgreementStatus.DISPUTED, "PeerPact: Not in dispute");
        require(
            _landlordShare + _tenantShare == a.depositAmount,
            "PeerPact: Shares must equal deposit"
        );

        a.status = AgreementStatus.RESOLVED;

        // Distribute deposit according to arbitrator ruling
        if (_landlordShare > 0) {
            stablecoin.transfer(a.landlord, _landlordShare);
        }
        if (_tenantShare > 0) {
            stablecoin.transfer(a.tenant, _tenantShare);
        }

        emit DisputeResolved(_agreementId, address(0), _landlordShare, _tenantShare);
    }

    // ─────────────────────────────────────────────
    //  INTERNAL FUNCTIONS
    // ─────────────────────────────────────────────

    /**
     * @dev Internal — auto-returns deposit to tenant at end of tenancy
     * Called automatically when all rent is paid OR both parties consent to end
     */
    function _endTenancy(uint256 _agreementId) internal {
        Agreement storage a = agreements[_agreementId];
        a.status = AgreementStatus.ENDED;

        // Auto-return full deposit to tenant — no human action needed
        if (a.depositLocked && a.depositAmount > 0) {
            stablecoin.transfer(a.tenant, a.depositAmount);
            emit DepositReturned(_agreementId, a.tenant, a.depositAmount);
        }

        emit TenancyEnded(_agreementId, block.timestamp);
    }

    // ─────────────────────────────────────────────
    //  VIEW FUNCTIONS — for frontend queries
    // ─────────────────────────────────────────────

    /// @notice Get full agreement details by ID
    function getAgreement(uint256 _id)
        external
        view
        agreementExists(_id)
        returns (Agreement memory)
    {
        return agreements[_id];
    }

    /// @notice Get all agreement IDs for a landlord
    function getLandlordAgreements(address _landlord)
        external
        view
        returns (uint256[] memory)
    {
        return landlordAgreements[_landlord];
    }

    /// @notice Get all agreement IDs for a tenant
    function getTenantAgreements(address _tenant)
        external
        view
        returns (uint256[] memory)
    {
        return tenantAgreements[_tenant];
    }

    /// @notice Check if rent is currently due for an agreement
    function isRentDue(uint256 _id)
        external
        view
        agreementExists(_id)
        returns (bool)
    {
        Agreement storage a = agreements[_id];
        if (a.status != AgreementStatus.ACTIVE) return false;
        if (a.rentPaidCount >= a.durationMonths) return false;
        return block.timestamp >= a.lastRentPaidAt + 25 days;
    }

    /// @notice Check if rent is overdue (past grace period)
    function isRentOverdue(uint256 _id)
        external
        view
        agreementExists(_id)
        returns (bool)
    {
        Agreement storage a = agreements[_id];
        if (a.status != AgreementStatus.ACTIVE) return false;
        return block.timestamp >= a.lastRentPaidAt + 25 days + GRACE_PERIOD;
    }

    /// @notice Get months remaining in tenancy
    function monthsRemaining(uint256 _id)
        external
        view
        agreementExists(_id)
        returns (uint256)
    {
        Agreement storage a = agreements[_id];
        if (a.rentPaidCount >= a.durationMonths) return 0;
        return a.durationMonths - a.rentPaidCount;
    }

    /// @notice Get all pending listings (available rooms)
    function getPendingListings() external view returns (uint256[] memory) {
        uint256 count = 0;
        for (uint256 i = 1; i <= agreementCount; i++) {
            if (agreements[i].status == AgreementStatus.PENDING) count++;
        }
        uint256[] memory result = new uint256[](count);
        uint256 idx = 0;
        for (uint256 i = 1; i <= agreementCount; i++) {
            if (agreements[i].status == AgreementStatus.PENDING) {
                result[idx++] = i;
            }
        }
        return result;
    }

    // ─────────────────────────────────────────────
    //  ADMIN FUNCTIONS
    // ─────────────────────────────────────────────

    /// @notice Transfer arbitrator role to a new address
    function transferArbitrator(address _newArbitrator) external onlyArbitrator {
        require(_newArbitrator != address(0), "PeerPact: Invalid address");
        arbitrator = _newArbitrator;
    }
}
