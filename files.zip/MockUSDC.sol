// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ============================================================
//  MockUSDC — Fake stablecoin for hackathon demo only
//  Deploy this FIRST, then pass its address to PeerPactRental
// ============================================================

contract MockUSDC {
    string  public name     = "Mock USD Coin";
    string  public symbol   = "mUSDC";
    uint8   public decimals = 6; // Same as real USDC

    uint256 public totalSupply;

    mapping(address => uint256)                     public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    /**
     * @notice Anyone can mint free mUSDC for testing
     * @param _amount Amount in USDC units (e.g. 1000_000000 = 1000 mUSDC)
     *
     * DEMO USE: Call this to give your test wallets stablecoin balance
     */
    function mint(address _to, uint256 _amount) external {
        balanceOf[_to] += _amount;
        totalSupply     += _amount;
        emit Transfer(address(0), _to, _amount);
    }

    function approve(address _spender, uint256 _amount) external returns (bool) {
        allowance[msg.sender][_spender] = _amount;
        emit Approval(msg.sender, _spender, _amount);
        return true;
    }

    function transfer(address _to, uint256 _amount) external returns (bool) {
        require(balanceOf[msg.sender] >= _amount, "MockUSDC: Insufficient balance");
        balanceOf[msg.sender] -= _amount;
        balanceOf[_to]        += _amount;
        emit Transfer(msg.sender, _to, _amount);
        return true;
    }

    function transferFrom(address _from, address _to, uint256 _amount) external returns (bool) {
        require(balanceOf[_from]               >= _amount, "MockUSDC: Insufficient balance");
        require(allowance[_from][msg.sender]   >= _amount, "MockUSDC: Insufficient allowance");
        balanceOf[_from]             -= _amount;
        balanceOf[_to]               += _amount;
        allowance[_from][msg.sender] -= _amount;
        emit Transfer(_from, _to, _amount);
        return true;
    }
}
